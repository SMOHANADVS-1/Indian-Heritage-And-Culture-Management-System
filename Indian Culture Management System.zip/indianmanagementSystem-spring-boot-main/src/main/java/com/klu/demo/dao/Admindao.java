package com.klu.demo.dao;



public interface Admindao {

	
	

}
